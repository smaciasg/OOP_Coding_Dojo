import padre

print(dir(padre))
print("\n///////////////////\n")
print(locals())